import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import FacebookPage from './pages/FacebookPage';
import TikTokPage from './pages/TikTokPage';
import AIToolsPage from './pages/AIToolsPage';
import FAQPage from './pages/FAQPage';
import BlogPage from './pages/BlogPage';
import NewsletterModal from './components/NewsletterModal';
import { NewsletterProvider } from './context/NewsletterContext';

function App() {
  return (
    <NewsletterProvider>
      <Router>
        <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-50 to-gray-100">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/facebook" element={<FacebookPage />} />
              <Route path="/tiktok" element={<TikTokPage />} />
              <Route path="/ai-tools" element={<AIToolsPage />} />
              <Route path="/faq" element={<FAQPage />} />
              <Route path="/blog" element={<BlogPage />} />
            </Routes>
          </main>
          <Footer />
          <NewsletterModal />
        </div>
      </Router>
    </NewsletterProvider>
  );
}

export default App;