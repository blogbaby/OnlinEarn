import React from 'react';
import { useNewsletterContext } from '../context/NewsletterContext';

interface CTAProps {
  title?: string;
  subtitle?: string;
  buttonText?: string;
}

const CTA: React.FC<CTAProps> = ({
  title = "Ready to Start Your Social Media Journey?",
  subtitle = "Join our newsletter to receive weekly tips, strategies, and opportunities to grow your social media income.",
  buttonText = "Subscribe Now"
}) => {
  const { setShowModal } = useNewsletterContext();

  return (
    <section className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden">
        <div className="absolute -top-24 -left-24 w-64 h-64 bg-white opacity-10 rounded-full"></div>
        <div className="absolute -bottom-32 -right-32 w-80 h-80 bg-white opacity-10 rounded-full"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10 flex flex-col items-center text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 max-w-2xl">{title}</h2>
        <p className="text-white text-opacity-90 max-w-2xl mb-8">{subtitle}</p>
        <a
          href="https://sawutser.top/4/8998632"
          onClick={(e) => {
            e.preventDefault();
            setShowModal(true);
          }}
          className="bg-white text-blue-600 hover:bg-gray-100 font-medium py-3 px-8 rounded-md transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg"
        >
          {buttonText}
        </a>
      </div>
    </section>
  );
};

export default CTA;