import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color?: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ 
  icon: Icon, 
  title, 
  description, 
  color = 'blue' 
}) => {
  const colorClasses = {
    blue: {
      bgLight: 'bg-blue-50',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      hoverBorder: 'group-hover:border-blue-200'
    },
    purple: {
      bgLight: 'bg-purple-50',
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600',
      hoverBorder: 'group-hover:border-purple-200'
    },
    pink: {
      bgLight: 'bg-pink-50',
      iconBg: 'bg-pink-100',
      iconColor: 'text-pink-600',
      hoverBorder: 'group-hover:border-pink-200'
    },
    green: {
      bgLight: 'bg-green-50',
      iconBg: 'bg-green-100',
      iconColor: 'text-green-600',
      hoverBorder: 'group-hover:border-green-200'
    }
  };

  const classes = colorClasses[color as keyof typeof colorClasses] || colorClasses.blue;

  return (
    <div className="group">
      <div className={`rounded-xl border border-gray-200 p-6 h-full transition-all duration-300 hover:shadow-md ${classes.hoverBorder}`}>
        <div className={`w-12 h-12 ${classes.iconBg} rounded-lg flex items-center justify-center mb-4`}>
          <Icon className={`h-6 w-6 ${classes.iconColor}`} />
        </div>
        <h3 className="font-semibold text-xl mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
};

export default FeatureCard;