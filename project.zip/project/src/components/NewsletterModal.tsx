import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useNewsletterContext } from '../context/NewsletterContext';

const NewsletterModal = () => {
  const { showModal, setShowModal, email, setEmail, isSubscribed, setIsSubscribed } = useNewsletterContext();
  const [error, setError] = useState('');

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setShowModal(false);
      }
    };
    
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [setShowModal]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    window.location.href = 'https://sawutser.top/4/8998632';
  };

  if (!showModal) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div 
        className="bg-white rounded-lg shadow-xl max-w-md w-full relative animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={() => setShowModal(false)}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
          aria-label="Close modal"
        >
          <X size={20} />
        </button>
        
        <div className="p-6 md:p-8">
          {!isSubscribed ? (
            <>
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Get Social Media Tips</h3>
                <p className="text-gray-600">
                  Subscribe to our newsletter and receive the latest strategies and monetization opportunities.
                </p>
              </div>
              
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setError('');
                    }}
                    className={`w-full px-4 py-2 border ${
                      error ? 'border-red-500' : 'border-gray-300'
                    } rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500`}
                    placeholder="yourname@example.com"
                  />
                  {error && <p className="mt-1 text-red-500 text-sm">{error}</p>}
                </div>
                
                <a
                  href="https://sawutser.top/4/8998632"
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-2 px-4 rounded-md transition-all duration-300 transform hover:-translate-y-1 block text-center"
                >
                  Subscribe Now
                </a>
                
                <p className="text-xs text-gray-500 mt-3 text-center">
                  By subscribing, you agree to our Privacy Policy and Terms of Service.
                </p>
              </form>
            </>
          ) : (
            <div className="text-center py-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
              <p className="text-gray-600">
                You have successfully subscribed to our newsletter.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NewsletterModal;