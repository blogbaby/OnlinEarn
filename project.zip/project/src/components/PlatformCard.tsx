import React from 'react';
import { ArrowRight } from 'lucide-react';

interface PlatformCardProps {
  title: string;
  description: string;
  image: string;
  link: string;
  gradient?: string;
}

const PlatformCard: React.FC<PlatformCardProps> = ({
  title,
  description,
  image,
  link,
  gradient = 'from-blue-500 to-blue-700'
}) => {
  return (
    <div className="overflow-hidden rounded-xl shadow-lg group">
      <div className="relative h-64">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className={`absolute inset-0 bg-gradient-to-b ${gradient} opacity-80`}></div>
        <div className="absolute inset-0 p-6 flex flex-col justify-end">
          <h3 className="text-white text-2xl font-bold mb-2">{title}</h3>
          <p className="text-white text-opacity-90 mb-4">{description}</p>
          <a 
            href={link}
            className="inline-flex items-center text-white bg-white bg-opacity-30 hover:bg-opacity-40 transition-all px-4 py-2 rounded-md w-max"
          >
            <span className="mr-2">Learn More</span>
            <ArrowRight size={16} />
          </a>
        </div>
      </div>
    </div>
  );
};

export default PlatformCard;