import React from 'react';

interface StepCardProps {
  number: number;
  title: string;
  description: string;
}

const StepCard: React.FC<StepCardProps> = ({ number, title, description }) => {
  return (
    <div className="relative pl-12 pb-8">
      {/* Step number */}
      <div className="absolute left-0 top-0 w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
        {number}
      </div>
      
      {/* Connector line */}
      {number > 1 && (
        <div className="absolute left-4 top-0 w-0.5 h-8 bg-blue-200 -translate-y-full"></div>
      )}
      
      {/* Content */}
      <div>
        <h3 className="font-semibold text-xl mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
      
      {/* Bottom connector */}
      <div className="absolute left-4 top-10 w-0.5 h-full bg-blue-200"></div>
    </div>
  );
};

export default StepCard;