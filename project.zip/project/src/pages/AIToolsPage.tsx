import React, { useEffect } from 'react';
import FeatureCard from '../components/FeatureCard';
import CTA from '../components/CTA';
import { Sparkles, PenTool, Video, Megaphone, MessageSquare, Lightbulb } from 'lucide-react';

const AIToolsPage = () => {
  useEffect(() => {
    document.title = 'AI Tools for Content Creation | SocialWealth';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28 bg-gradient-to-br from-indigo-50 to-purple-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Leverage AI Tools for Content Creation
            </h1>
            <p className="text-xl text-gray-700 mb-8">
              Discover how to use cutting-edge AI tools to create better content faster and grow your social media presence efficiently.
            </p>
            <div className="flex justify-center">
              <img
                src="https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="AI content creation"
                className="rounded-lg shadow-xl w-full max-w-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* AI Tools Categories Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Essential AI Tools for Content Creators</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              These AI-powered tools can help you create engaging content, save time, and grow your audience across platforms.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={Sparkles}
              title="Content Generation"
              description="AI tools that help create scripts, captions, and ideas for your social media posts, saving hours of brainstorming time."
              color="indigo"
            />
            <FeatureCard
              icon={PenTool}
              title="Image Creation"
              description="Generate custom images and graphics for your posts without design skills using text-to-image AI tools."
              color="purple"
            />
            <FeatureCard
              icon={Video}
              title="Video Editing"
              description="Automated video editing tools that can trim clips, add captions, and even suggest edits based on engagement patterns."
              color="indigo"
            />
            <FeatureCard
              icon={Megaphone}
              title="Content Repurposing"
              description="Tools that help transform content from one format to another, like turning blog posts into short-form videos."
              color="purple"
            />
            <FeatureCard
              icon={MessageSquare}
              title="Social Engagement"
              description="AI that helps you respond to comments and messages efficiently while maintaining your authentic voice."
              color="indigo"
            />
            <FeatureCard
              icon={Lightbulb}
              title="Trend Analysis"
              description="Tools that identify trending topics and hashtags in your niche before they go mainstream."
              color="purple"
            />
          </div>
        </div>
      </section>

      {/* Recommended Tools Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Top AI Tools for Social Media Creators</h2>
              <p className="text-lg text-gray-600">
                Our recommended AI tools that help streamline your content creation workflow.
              </p>
            </div>

            <div className="space-y-8">
              {/* Tool 1 */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mr-4">
                      <Sparkles className="h-6 w-6 text-indigo-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xl">ChatGPT</h3>
                      <p className="text-gray-600">Content Generation</p>
                    </div>
                  </div>
                  <p className="text-gray-700 mb-4">
                    An AI assistant that can help write scripts, generate content ideas, create captions, and even research trending topics in your niche.
                  </p>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">How to use it for social media:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-700">
                      <li>Generate multiple hook ideas for TikTok videos</li>
                      <li>Create engaging captions with relevant hashtags</li>
                      <li>Develop content series ideas for consistent posting</li>
                      <li>Get help rewriting captions for different platforms</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Tool 2 */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                      <PenTool className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xl">DALL-E / Midjourney</h3>
                      <p className="text-gray-600">Image Generation</p>
                    </div>
                  </div>
                  <p className="text-gray-700 mb-4">
                    Text-to-image AI tools that can create custom visuals for your social media posts without requiring design skills.
                  </p>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">How to use it for social media:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-700">
                      <li>Create custom thumbnails that stand out</li>
                      <li>Generate branded graphics for quotes and tips</li>
                      <li>Design unique backgrounds for text overlays</li>
                      <li>Create visual metaphors to illustrate complex concepts</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Tool 3 */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mr-4">
                      <Video className="h-6 w-6 text-indigo-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xl">CapCut / Descript</h3>
                      <p className="text-gray-600">Video Editing & Auto-Captions</p>
                    </div>
                  </div>
                  <p className="text-gray-700 mb-4">
                    AI-powered video editing tools that automatically transcribe your content and add captions, simplifying the editing process.
                  </p>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">How to use it for social media:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-700">
                      <li>Auto-generate captions for higher engagement</li>
                      <li>Remove filler words from your recording automatically</li>
                      <li>Use AI templates to create professional edits quickly</li>
                      <li>Transcribe videos for repurposing as blog content</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Tool 4 */}
              <div className="bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg">
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                      <Megaphone className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-xl">Repurpose.io</h3>
                      <p className="text-gray-600">Content Repurposing</p>
                    </div>
                  </div>
                  <p className="text-gray-700 mb-4">
                    A tool that helps you automatically repurpose content across multiple platforms to maximize your reach without extra work.
                  </p>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">How to use it for social media:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-gray-700">
                      <li>Turn long videos into short clips for TikTok and Reels</li>
                      <li>Extract audio to create podcast episodes</li>
                      <li>Convert videos to blog posts with proper formatting</li>
                      <li>Automatically share content across multiple platforms</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Best Practices Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">AI Tools Best Practices</h2>
              <p className="text-lg text-gray-600">
                Follow these guidelines to get the most out of AI tools while maintaining authenticity.
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-indigo-50 rounded-lg p-6 border-l-4 border-indigo-500">
                <h3 className="font-semibold text-xl mb-2">Maintain Your Voice</h3>
                <p className="text-gray-700">
                  Always edit AI-generated content to match your authentic voice and style. Add personal anecdotes and experiences to keep content relatable and genuine.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 border-l-4 border-purple-500">
                <h3 className="font-semibold text-xl mb-2">Focus on Value First</h3>
                <p className="text-gray-700">
                  Use AI to enhance your content, not replace your expertise. Ensure every piece of content provides real value to your audience, with AI serving as a tool to improve delivery.
                </p>
              </div>

              <div className="bg-indigo-50 rounded-lg p-6 border-l-4 border-indigo-500">
                <h3 className="font-semibold text-xl mb-2">Verify Information</h3>
                <p className="text-gray-700">
                  Always fact-check information provided by AI tools before publishing. AI can sometimes generate inaccurate information that could damage your credibility.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 border-l-4 border-purple-500">
                <h3 className="font-semibold text-xl mb-2">Create an Efficient Workflow</h3>
                <p className="text-gray-700">
                  Develop a systematic approach to using AI tools in your content creation process. Set up templates and prompts that you can reuse to maintain consistency and save time.
                </p>
              </div>

              <div className="bg-indigo-50 rounded-lg p-6 border-l-4 border-indigo-500">
                <h3 className="font-semibold text-xl mb-2">Test and Iterate</h3>
                <p className="text-gray-700">
                  Regularly analyze which AI-assisted content performs best and refine your approach accordingly. Different audiences respond differently to AI-enhanced content.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTA 
        title="Master AI-Powered Content Creation"
        subtitle="Subscribe to receive our advanced AI prompts and workflows specifically designed for social media creators."
        buttonText="Get AI Tips"
      />
    </div>
  );
};

export default AIToolsPage;