import React, { useEffect, useState } from 'react';
import BlogCard from '../components/BlogCard';
import CTA from '../components/CTA';

const BlogPage = () => {
  useEffect(() => {
    document.title = 'Blog | SocialWealth';
    window.scrollTo(0, 0);
  }, []);

  const [activeCategory, setActiveCategory] = useState('all');

  const blogPosts = [
    {
      id: 1,
      title: "10 TikTok Trends That Are Driving Massive Engagement in 2025",
      excerpt: "Discover the latest TikTok trends that are helping creators go viral and build engaged audiences quickly, with examples and implementation tips.",
      date: "April 15, 2025",
      image: "https://images.pexels.com/photos/5077393/pexels-photo-5077393.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "tiktok"
    },
    {
      id: 2,
      title: "How I Made $5,342 Last Month With Facebook Affiliate Marketing",
      excerpt: "A detailed case study showing how one creator leveraged Facebook Groups and Page content to generate significant affiliate income without a huge following.",
      date: "April 10, 2025",
      image: "https://images.pexels.com/photos/6953867/pexels-photo-6953867.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
      category: "facebook"
    },
    {
      id: 3,
      title: "5 AI Tools That Cut My Content Creation Time in Half",
      excerpt: "A review of the most effective AI tools for social media content creation, with step-by-step workflows and prompt templates to maximize efficiency.",
      date: "April 5, 2025",
      image: "https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "ai-tools"
    },
    {
      id: 4,
      title: "Facebook Reels Strategy: How to Get 100K Views Consistently",
      excerpt: "A comprehensive guide to creating Facebook Reels that consistently reach large audiences, including optimal posting times and content formulas.",
      date: "March 30, 2025",
      image: "https://images.pexels.com/photos/935979/pexels-photo-935979.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "facebook"
    },
    {
      id: 5,
      title: "From TikTok to Email List: Converting Followers to Subscribers",
      excerpt: "Learn how to build an email list from your TikTok audience, creating a more stable income source that isn't dependent on algorithm changes.",
      date: "March 25, 2025",
      image: "https://images.pexels.com/photos/6953879/pexels-photo-6953879.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "tiktok"
    },
    {
      id: 6,
      title: "The Ultimate Guide to TikTok's Creator Marketplace",
      excerpt: "Everything you need to know about accessing and maximizing opportunities in TikTok's Creator Marketplace to secure brand deals and sponsorships.",
      date: "March 20, 2025",
      image: "https://images.pexels.com/photos/3944104/pexels-photo-3944104.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "tiktok"
    },
    {
      id: 7,
      title: "How to Use ChatGPT to Generate a Month of Social Content in 1 Hour",
      excerpt: "A detailed tutorial on using AI to batch-create social media content, including prompts that generate engaging hooks, scripts, and captions.",
      date: "March 15, 2025",
      image: "https://images.pexels.com/photos/4145190/pexels-photo-4145190.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "ai-tools"
    },
    {
      id: 8,
      title: "Facebook Groups: The Untapped Goldmine for Content Creators",
      excerpt: "Why Facebook Groups may be the most overlooked monetization opportunity, and how to build and monetize a group without appearing salesy.",
      date: "March 10, 2025",
      image: "https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "facebook"
    },
    {
      id: 9,
      title: "The Psychology Behind Viral TikTok Content: What Actually Works",
      excerpt: "An analysis of 100 viral TikTok videos to identify the psychological triggers that make content shareable and how to ethically incorporate them.",
      date: "March 5, 2025",
      image: "https://images.pexels.com/photos/4004374/pexels-photo-4004374.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
      category: "tiktok"
    }
  ];

  const filteredPosts = activeCategory === 'all' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === activeCategory);

  const categories = [
    { id: 'all', name: 'All Posts' },
    { id: 'facebook', name: 'Facebook' },
    { id: 'tiktok', name: 'TikTok' },
    { id: 'ai-tools', name: 'AI Tools' }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-20 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Social Media Monetization Blog
            </h1>
            <p className="text-xl text-gray-700">
              Actionable strategies, tips, and case studies to help you monetize your social media presence.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Categories */}
      <section className="py-8 bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-wrap justify-center gap-2 md:gap-4">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeCategory === category.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.map(post => (
              <BlogCard
                key={post.id}
                title={post.title}
                excerpt={post.excerpt}
                date={post.date}
                image={post.image}
                category={post.category === 'facebook' ? 'Facebook' : post.category === 'tiktok' ? 'TikTok' : 'AI Tools'}
              />
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-xl font-medium text-gray-700 mb-2">No posts found</h3>
              <p className="text-gray-500">Try selecting a different category</p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Never Miss an Update</h2>
            <p className="text-lg text-gray-600 mb-8">
              Subscribe to our newsletter to receive the latest blog posts, tips, and monetization strategies directly to your inbox.
            </p>
            <div className="flex justify-center">
              <button 
                onClick={() => {
                  const newsletterContext = document.querySelector("[data-newsletter-context]");
                  if (newsletterContext) {
                    const setShowModal = newsletterContext.getAttribute("data-show-modal");
                    if (setShowModal) {
                      window[setShowModal](true);
                    }
                  }
                }}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3 px-8 rounded-md transition-all duration-300 transform hover:-translate-y-1"
              >
                Subscribe to Newsletter
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTA 
        title="Ready to Implement These Strategies?"
        subtitle="Sign up for personalized guidance on turning these insights into action for your social media presence."
        buttonText="Start Now"
      />
    </div>
  );
};

export default BlogPage;