import React, { useEffect } from 'react';
import FAQItem from '../components/FAQItem';
import CTA from '../components/CTA';

const FAQPage = () => {
  useEffect(() => {
    document.title = 'Frequently Asked Questions | SocialWealth';
    window.scrollTo(0, 0);
  }, []);

  const generalFaqs = [
    {
      question: "How quickly can I start making money on social media?",
      answer: "The timeline varies greatly depending on your niche, content quality, consistency, and monetization methods. Some creators see their first earnings within 1-3 months, while others might take 6-12 months to generate significant income. Focus on building an engaged audience first rather than immediate monetization."
    },
    {
      question: "Do I need a large following to make money?",
      answer: "Not necessarily. While a larger audience can provide more monetization opportunities, many creators with smaller, highly-engaged audiences (1,000-10,000 followers) successfully generate income through affiliate marketing, selling digital products, or securing niche brand partnerships. Quality engagement often matters more than quantity."
    },
    {
      question: "Which platform is better for monetization - Facebook or TikTok?",
      answer: "It depends on your content style, target audience, and personal strengths. TikTok typically offers faster growth potential for new creators but can be more competitive. Facebook has more established monetization programs and tends to have higher-value audiences for certain niches like business, parenting, or education. Many successful creators use both platforms by repurposing content."
    },
    {
      question: "How much time do I need to commit daily?",
      answer: "For meaningful growth, plan to spend at least 1-2 hours daily on content creation, engagement, and strategy. Successful creators typically devote 2-4 hours daily when building their audience. As you grow, you can use AI tools and potentially outsource some tasks to reduce your personal time investment."
    }
  ];

  const facebookFaqs = [
    {
      question: "What are the requirements for Facebook monetization?",
      answer: "To access Facebook's official monetization programs, you generally need: 1) At least 10,000 followers on your Facebook page, 2) 600,000 total minutes viewed across all your videos in the last 60 days, 3) 5 or more active video uploads, 4) Compliance with Facebook's monetization policies and community guidelines."
    },
    {
      question: "Is Facebook still relevant for new content creators?",
      answer: "Absolutely. While it may seem saturated, Facebook remains the largest social platform with over 3 billion users. The key is finding underserved niches and leveraging Facebook Groups, which often have higher engagement than pages. Facebook also tends to have an older demographic with higher purchasing power compared to TikTok."
    },
    {
      question: "How do Facebook Reels compare to TikTok for growth?",
      answer: "Facebook Reels currently offer excellent organic reach as Facebook is heavily promoting this format to compete with TikTok. Many creators report faster growth with Reels than with traditional Facebook posts. The content style is similar to TikTok, but typically performs better with slightly longer videos (30-60 seconds) and more informative content."
    }
  ];

  const tiktokFaqs = [
    {
      question: "How does the TikTok Creator Fund work?",
      answer: "The TikTok Creator Fund pays creators based on video performance, including views, engagement, and regional factors. Payment rates vary widely, typically ranging from $0.02-$0.04 per 1,000 views. To qualify, you need at least 10,000 followers and 100,000 video views in the last 30 days. Most creators find the Creator Fund provides supplemental income rather than significant revenue."
    },
    {
      question: "How do I go viral on TikTok?",
      answer: "While there's no guaranteed formula, videos with higher chances of going viral typically have: 1) A strong hook in the first 3 seconds, 2) Trending audio or effects, 3) Concise, valuable content that creates an emotional response, 4) Call-to-action for engagement, 5) Proper hashtags mixing trending and niche terms. Consistency is also crucial - most 'overnight successes' posted daily for months before going viral."
    },
    {
      question: "Can I repurpose my TikTok content on other platforms?",
      answer: "Yes, and it's highly recommended. Creating content for multiple platforms from scratch is time-consuming. Many successful creators film content with TikTok, then repurpose to Facebook Reels, Instagram Reels, and YouTube Shorts. Just be careful with TikTok watermarks, as some platforms (especially Instagram) may limit the reach of content with visible TikTok branding."
    }
  ];

  const aiToolsFaqs = [
    {
      question: "Will my audience know I'm using AI tools?",
      answer: "If used properly, your audience won't recognize content created with AI assistance. The key is to use AI as a starting point, then edit thoroughly to inject your personality, experiences, and unique perspective. Avoid publishing raw AI outputs without customization, as they often have recognizable patterns that savvy followers might identify."
    },
    {
      question: "Are AI tools expensive for beginners?",
      answer: "Many powerful AI tools offer free tiers or affordable options for beginners. For example, ChatGPT has a free version, CapCut offers free auto-captions, and Canva includes AI features in its free tier. As your content business grows, premium AI tools ($10-$30/month) can be worthwhile investments that save hours of work daily."
    },
    {
      question: "How can I make my AI-assisted content more authentic?",
      answer: "Always add personal stories, examples from your own experience, and your unique voice to AI-generated content. Use AI for structure and ideas, but infuse your personality through editing. Record content naturally rather than reading scripts verbatim, and incorporate your genuine reactions and emotions."
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-16 md:pt-40 md:pb-20 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-700">
              Find answers to common questions about social media monetization, platform strategies, and content creation.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Sections */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            {/* General FAQs */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold mb-8 pb-2 border-b border-gray-200">
                General Questions
              </h2>
              <div className="space-y-2">
                {generalFaqs.map((faq, index) => (
                  <FAQItem
                    key={index}
                    question={faq.question}
                    answer={faq.answer}
                  />
                ))}
              </div>
            </div>

            {/* Facebook FAQs */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold mb-8 pb-2 border-b border-gray-200">
                Facebook Monetization
              </h2>
              <div className="space-y-2">
                {facebookFaqs.map((faq, index) => (
                  <FAQItem
                    key={index}
                    question={faq.question}
                    answer={faq.answer}
                  />
                ))}
              </div>
            </div>

            {/* TikTok FAQs */}
            <div className="mb-16">
              <h2 className="text-2xl font-bold mb-8 pb-2 border-b border-gray-200">
                TikTok Monetization
              </h2>
              <div className="space-y-2">
                {tiktokFaqs.map((faq, index) => (
                  <FAQItem
                    key={index}
                    question={faq.question}
                    answer={faq.answer}
                  />
                ))}
              </div>
            </div>

            {/* AI Tools FAQs */}
            <div>
              <h2 className="text-2xl font-bold mb-8 pb-2 border-b border-gray-200">
                AI Tools for Content Creation
              </h2>
              <div className="space-y-2">
                {aiToolsFaqs.map((faq, index) => (
                  <FAQItem
                    key={index}
                    question={faq.question}
                    answer={faq.answer}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Help Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Still Have Questions?</h2>
            <p className="text-lg text-gray-600 mb-8">
              Our team is ready to help you with any specific questions about social media monetization or content creation strategies.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a 
                href="mailto:support@socialwealth.com" 
                className="bg-white text-gray-800 border border-gray-300 hover:bg-gray-100 font-medium py-3 px-6 rounded-md transition-all duration-300 text-center"
              >
                Contact Support
              </a>
              <button 
                onClick={() => window.location.href = '/blog'} 
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3 px-6 rounded-md transition-all duration-300 text-center"
              >
                Explore Our Blog
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTA 
        title="Ready To Start Your Social Media Journey?"
        subtitle="Subscribe to our newsletter for weekly tips, platform updates, and monetization strategies."
      />
    </div>
  );
};

export default FAQPage;