import React, { useEffect } from 'react';
import StepCard from '../components/StepCard';
import FeatureCard from '../components/FeatureCard';
import CTA from '../components/CTA';
import { Users, TrendingUp, ShoppingBag, DollarSign, BarChart, Gift } from 'lucide-react';

const FacebookPage = () => {
  useEffect(() => {
    document.title = 'Facebook Monetization Strategies | SocialWealth';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28 bg-gradient-to-br from-blue-50 to-blue-100">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Master Facebook Monetization
            </h1>
            <p className="text-xl text-gray-700 mb-8">
              Learn proven strategies to turn your Facebook presence into a reliable source of income, even if you're starting from scratch.
            </p>
            <div className="flex justify-center">
              <img
                src="https://images.pexels.com/photos/5077047/pexels-photo-5077047.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Facebook marketing"
                className="rounded-lg shadow-xl w-full max-w-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Getting Started Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Getting Started on Facebook</h2>
              <p className="text-lg text-gray-600">
                Follow these steps to build a solid foundation for your Facebook monetization journey.
              </p>
            </div>

            <div className="space-y-8">
              <StepCard
                number={1}
                title="Create a Professional Page"
                description="Set up a Facebook Business Page focused on a specific niche that you're passionate about and knowledgeable in. Choose a catchy name and upload a professional profile picture and cover photo."
              />
              <StepCard
                number={2}
                title="Define Your Target Audience"
                description="Research and identify your ideal audience. Understanding demographics, interests, and pain points will help you create content that resonates and grows your following."
              />
              <StepCard
                number={3}
                title="Develop a Content Strategy"
                description="Plan a mix of educational, entertaining, and promotional content. Consistency is key - create a posting schedule and stick to it to build audience expectations."
              />
              <StepCard
                number={4}
                title="Grow Your Audience"
                description="Use Facebook groups, engage with similar pages, run contests, and consider Facebook ads to expand your reach and grow your following authentically."
              />
              <StepCard
                number={5}
                title="Implement Monetization Methods"
                description="Once you've built an engaged audience, begin implementing various monetization strategies outlined in the next section."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Monetization Methods Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Facebook Monetization Methods</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Explore these proven strategies to generate income from your Facebook presence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={ShoppingBag}
              title="Affiliate Marketing"
              description="Promote products or services and earn commissions for every sale made through your unique tracking link. Focus on products relevant to your audience."
              color="blue"
            />
            <FeatureCard
              icon={Users}
              title="Brand Partnerships"
              description="Collaborate with brands for sponsored posts, reviews, and content creation. As your audience grows, you can command higher rates for brand deals."
              color="purple"
            />
            <FeatureCard
              icon={DollarSign}
              title="Facebook Monetization Tools"
              description="Utilize in-stream ads, fan subscriptions, and Stars once you qualify for Facebook's official monetization programs."
              color="blue"
            />
            <FeatureCard
              icon={TrendingUp}
              title="Digital Products"
              description="Create and sell ebooks, courses, templates, or other digital products that solve problems for your audience."
              color="purple"
            />
            <FeatureCard
              icon={BarChart}
              title="Facebook Groups"
              description="Build a premium, paid Facebook group where you provide exclusive content, coaching, or community to members."
              color="blue"
            />
            <FeatureCard
              icon={Gift}
              title="Influencer Marketing"
              description="As your page grows, join influencer networks to get matched with brands looking for promotion within your niche."
              color="purple"
            />
          </div>
        </div>
      </section>

      {/* Tips for Success Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Tips for Facebook Success</h2>
              <p className="text-lg text-gray-600">
                Master these strategies to maximize your monetization potential on Facebook.
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-blue-500">
                <h3 className="font-semibold text-xl mb-2">Focus on Video Content</h3>
                <p className="text-gray-700">
                  Facebook's algorithm favors video content, especially live videos. Create engaging videos to increase reach and engagement. Aim for 3-5 minute videos that deliver value quickly.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 border-l-4 border-purple-500">
                <h3 className="font-semibold text-xl mb-2">Engage With Your Community</h3>
                <p className="text-gray-700">
                  Respond to comments, ask questions, and create polls to boost engagement. The more your audience interacts with your content, the more the algorithm will favor it.
                </p>
              </div>

              <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-blue-500">
                <h3 className="font-semibold text-xl mb-2">Analyze Your Insights</h3>
                <p className="text-gray-700">
                  Regularly check your Facebook Insights to understand what content performs best. Use this data to refine your strategy and create more of what your audience loves.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 border-l-4 border-purple-500">
                <h3 className="font-semibold text-xl mb-2">Build Your Email List</h3>
                <p className="text-gray-700">
                  Don't rely solely on Facebook. Use your page to build an email list so you have direct access to your audience outside of the platform's algorithms.
                </p>
              </div>

              <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-blue-500">
                <h3 className="font-semibold text-xl mb-2">Create Theme Days</h3>
                <p className="text-gray-700">
                  Establish theme days for your content (e.g., Motivation Monday, Tutorial Tuesday) to create consistency and help your audience know what to expect.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Case Study Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="md:flex">
                <div className="md:w-1/3">
                  <img
                    src="https://images.pexels.com/photos/3194518/pexels-photo-3194518.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                    alt="Success Story"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-8 md:w-2/3">
                  <div className="uppercase tracking-wide text-sm text-blue-600 font-semibold">Case Study</div>
                  <h2 className="mt-2 text-2xl font-semibold text-gray-900">From 0 to $5,000 Monthly: A Facebook Success Story</h2>
                  <p className="mt-4 text-gray-600">
                    John started a Facebook Page focused on home workout routines during the pandemic. Within 6 months, he grew to 100,000 followers by posting daily workout videos and tips. 
                  </p>
                  <p className="mt-2 text-gray-600">
                    He monetized his page through a combination of affiliate marketing for fitness equipment, launching his own workout program, and brand partnerships with supplement companies. 
                  </p>
                  <p className="mt-2 text-gray-600">
                    Key to his success was consistency, high-quality video content, and genuinely engaging with his community. He now generates over $5,000 monthly from his Facebook presence.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTA 
        title="Ready to Start Your Facebook Monetization Journey?"
        subtitle="Subscribe to receive our advanced Facebook monetization strategies and stay updated with platform changes and opportunities."
      />
    </div>
  );
};

export default FacebookPage;