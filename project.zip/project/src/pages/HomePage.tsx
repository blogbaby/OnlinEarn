import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, DollarSign, Users, Zap } from 'lucide-react';
import FeatureCard from '../components/FeatureCard';
import PlatformCard from '../components/PlatformCard';
import TestimonialCard from '../components/TestimonialCard';
import CTA from '../components/CTA';

const HomePage = () => {
  useEffect(() => {
    document.title = 'SocialWealth - Make Money on Social Media';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
              Turn Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Social Media</span> Into a Source of Income
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Learn proven strategies to monetize your Facebook and TikTok presence with step-by-step guides for beginners.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="https://sawutser.top/4/8998632"
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium py-3 px-6 rounded-md transition-all duration-300 text-center transform hover:-translate-y-1"
              >
                Facebook Strategies
              </a>
              <a 
                href="https://sawutser.top/4/8998632"
                className="bg-white text-gray-800 border border-gray-300 hover:bg-gray-100 font-medium py-3 px-6 rounded-md transition-all duration-300 text-center transform hover:-translate-y-1"
              >
                TikTok Strategies
              </a>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <img 
              src="https://images.pexels.com/photos/6953867/pexels-photo-6953867.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
              alt="Person on social media" 
              className="rounded-lg shadow-2xl max-w-md w-full object-cover"
            />
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Learn With Us?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We provide everything you need to start earning from your social media presence, regardless of your experience level.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={TrendingUp} 
              title="Growth Strategies" 
              description="Learn proven techniques to grow your audience organically on both platforms."
              color="blue"
            />
            <FeatureCard 
              icon={DollarSign} 
              title="Monetization Methods" 
              description="Explore multiple income streams, from affiliate marketing to brand partnerships."
              color="purple"
            />
            <FeatureCard 
              icon={Users} 
              title="Audience Engagement" 
              description="Master the art of creating engaging content that keeps your audience coming back."
              color="pink"
            />
            <FeatureCard 
              icon={Zap} 
              title="AI-Powered Tools" 
              description="Use cutting-edge AI tools to create better content in less time."
              color="green"
            />
          </div>
        </div>
      </section>
      
      {/* Platforms Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Choose Your Platform</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Each social media platform offers unique monetization opportunities. Learn strategies tailored for your preferred platform.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <PlatformCard 
              title="Facebook Monetization" 
              description="Learn how to leverage Facebook's massive user base to create income streams."
              image="https://images.pexels.com/photos/2818118/pexels-photo-2818118.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              link="https://sawutser.top/4/8998632"
              gradient="from-blue-600 to-blue-800"
            />
            <PlatformCard 
              title="TikTok Monetization" 
              description="Discover how to turn viral short-form videos into steady income."
              image="https://images.pexels.com/photos/5077393/pexels-photo-5077393.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
              link="https://sawutser.top/4/8998632"
              gradient="from-pink-500 to-purple-700"
            />
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Success Stories</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Here's what others have achieved by following our strategies.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TestimonialCard 
              quote="I went from 0 to 50,000 followers on TikTok in just 3 months using these strategies, and now I'm making $3,000 monthly from brand deals!"
              name="Sarah Johnson"
              title="Fashion Influencer"
              image="https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
            <TestimonialCard 
              quote="The Facebook monetization guide helped me turn my cooking hobby into a business. Now I earn more from my Facebook page than I did at my day job."
              name="Michael Rodriguez"
              title="Food Content Creator"
              image="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
            <TestimonialCard 
              quote="I was skeptical at first, but after implementing the AI content creation strategies, I've been able to post daily and grow my audience exponentially."
              name="Lisa Zhang"
              title="Lifestyle Creator"
              image="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            />
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <CTA />
    </div>
  );
};

export default HomePage;