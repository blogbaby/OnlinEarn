import React, { useEffect } from 'react';
import StepCard from '../components/StepCard';
import FeatureCard from '../components/FeatureCard';
import CTA from '../components/CTA';
import { Sparkles, Users, TrendingUp, ShoppingBag, DollarSign, Gift } from 'lucide-react';

const TikTokPage = () => {
  useEffect(() => {
    document.title = 'TikTok Monetization Strategies | SocialWealth';
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-28 bg-gradient-to-br from-pink-50 to-purple-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              TikTok Monetization Mastery
            </h1>
            <p className="text-xl text-gray-700 mb-8">
              Learn how to create viral content, grow your following, and turn your TikTok presence into a profitable business.
            </p>
            <div className="flex justify-center">
              <img
                src="https://images.pexels.com/photos/5081396/pexels-photo-5081396.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="TikTok creator"
                className="rounded-lg shadow-xl w-full max-w-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Getting Started Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Getting Started on TikTok</h2>
              <p className="text-lg text-gray-600">
                Follow these steps to build a solid foundation for your TikTok success.
              </p>
            </div>

            <div className="space-y-8">
              <StepCard
                number={1}
                title="Create an Optimized Profile"
                description="Set up a business account with a memorable username, professional profile picture, and compelling bio that clearly states what you do and includes a call-to-action."
              />
              <StepCard
                number={2}
                title="Find Your Niche"
                description="Focus on a specific content category that you're passionate about. Niching down helps the algorithm understand your content and connect you with the right audience."
              />
              <StepCard
                number={3}
                title="Study Trending Content"
                description="Spend time on the app to understand what's trending in your niche. Analyze successful creators' content structures, hooks, and editing styles."
              />
              <StepCard
                number={4}
                title="Create High-Quality Content"
                description="Invest in good lighting and clear audio. Keep videos concise with strong hooks in the first 3 seconds. Use trending sounds and effects to boost visibility."
              />
              <StepCard
                number={5}
                title="Post Consistently"
                description="Aim for daily posting, especially when starting. TikTok's algorithm favors accounts that post regularly and consistently engage with the platform."
              />
            </div>
          </div>
        </div>
      </section>

      {/* Monetization Methods Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">TikTok Monetization Methods</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Explore these proven strategies to generate income from your TikTok presence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={Sparkles}
              title="TikTok Creator Fund"
              description="Once you reach 10,000 followers and 100,000 views in the last 30 days, apply for the Creator Fund to earn money directly from TikTok based on video performance."
              color="pink"
            />
            <FeatureCard
              icon={DollarSign}
              title="LIVE Gifts"
              description="After reaching 1,000 followers, you can go live and receive virtual gifts from viewers that convert to real money through Diamonds."
              color="purple"
            />
            <FeatureCard
              icon={Users}
              title="Brand Partnerships"
              description="Collaborate with brands for sponsored content. Even with a smaller following, you can secure deals if you have high engagement in a specific niche."
              color="pink"
            />
            <FeatureCard
              icon={ShoppingBag}
              title="Affiliate Marketing"
              description="Promote products with your unique tracking links and earn commissions. Link in bio and TikTok Shop integration can boost conversion rates."
              color="purple"
            />
            <FeatureCard
              icon={TrendingUp}
              title="Selling Products/Services"
              description="Use TikTok to drive traffic to your own products or services. Digital products like courses or templates work especially well."
              color="pink"
            />
            <FeatureCard
              icon={Gift}
              title="TikTok Shop"
              description="If available in your region, integrate TikTok Shop to sell products directly through your videos and live streams."
              color="purple"
            />
          </div>
        </div>
      </section>

      {/* Viral Content Strategies Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Viral Content Strategies</h2>
              <p className="text-lg text-gray-600">
                Master these techniques to increase your chances of creating viral TikTok content.
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-pink-50 rounded-lg p-6 border-l-4 border-pink-500">
                <h3 className="font-semibold text-xl mb-2">Create Strong Hooks</h3>
                <p className="text-gray-700">
                  You have just 1-3 seconds to grab attention. Start with a provocative question, surprising statement, or intriguing visual to keep viewers watching.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 border-l-4 border-purple-500">
                <h3 className="font-semibold text-xl mb-2">Follow Trends Strategically</h3>
                <p className="text-gray-700">
                  Put your unique spin on trending sounds, challenges, and formats. The algorithm favors content using trending elements, but originality helps you stand out.
                </p>
              </div>

              <div className="bg-pink-50 rounded-lg p-6 border-l-4 border-pink-500">
                <h3 className="font-semibold text-xl mb-2">Optimize Your Posting Schedule</h3>
                <p className="text-gray-700">
                  Post when your audience is most active. Check your TikTok analytics to identify optimal posting times, typically 3 times daily for maximum reach.
                </p>
              </div>

              <div className="bg-purple-50 rounded-lg p-6 border-l-4 border-purple-500">
                <h3 className="font-semibold text-xl mb-2">Create Loop-worthy Content</h3>
                <p className="text-gray-700">
                  Design videos that viewers want to watch multiple times. Seamless loops, surprising endings, or complex information that requires multiple views boost your completion rate.
                </p>
              </div>

              <div className="bg-pink-50 rounded-lg p-6 border-l-4 border-pink-500">
                <h3 className="font-semibold text-xl mb-2">Use Strategic Hashtags</h3>
                <p className="text-gray-700">
                  Mix trending hashtags with niche-specific ones. Limit to 3-5 relevant hashtags per video rather than overloading with too many.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Case Study Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="md:flex">
                <div className="md:w-1/3">
                  <img
                    src="https://images.pexels.com/photos/6884065/pexels-photo-6884065.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                    alt="TikTok Success Story"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-8 md:w-2/3">
                  <div className="uppercase tracking-wide text-sm text-pink-600 font-semibold">Case Study</div>
                  <h2 className="mt-2 text-2xl font-semibold text-gray-900">From 0 to 500K: A TikTok Success Story</h2>
                  <p className="mt-4 text-gray-600">
                    Emma started her TikTok journey sharing quick finance tips for beginners. She consistently posted 3 videos daily, focusing on answering common money questions in 30-60 second clips.
                  </p>
                  <p className="mt-2 text-gray-600">
                    Within 4 months, one of her videos explaining credit scores went viral with 2.3 million views, catapulting her following to over 100K. She continued growing by responding to comments with personalized advice videos.
                  </p>
                  <p className="mt-2 text-gray-600">
                    She now monetizes through a combination of affiliate marketing for financial apps, brand deals with fintech companies, and her own $27 budgeting template that generates $8,000-$12,000 monthly.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CTA 
        title="Ready to Launch Your TikTok Success Journey?"
        subtitle="Subscribe to receive our advanced TikTok growth and monetization strategies, including weekly trend updates."
        buttonText="Get TikTok Tips"
      />
    </div>
  );
};

export default TikTokPage;